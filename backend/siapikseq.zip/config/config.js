module.exports = {
  "development": {
    "username": "postgres",
    "password": "Cerbon21",
    "database": "bps_assessment_v2",
    "host": "127.0.0.1",
    "dialect": "postgres"
  },
  "production": {
    "username": "siapikwe_userbps",
    "password": "Bps.pring1000",
    "database": "siapikwe_bps",
    "host": "localhost",
    "port": 5432,
    "dialect": "postgres"
  }
};